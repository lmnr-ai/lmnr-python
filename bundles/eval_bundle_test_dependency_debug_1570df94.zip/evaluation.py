"""
Simple evaluation for testing dependency detection and installation
"""
from lmnr import executor, evaluator
import json


@executor()
async def my_executor(data):
    """Simple executor that just returns the input"""
    return {"result": data.get("input", "default")}


@evaluator("accuracy")
async def accuracy_evaluator(output, target):
    """Simple evaluator that checks exact match"""
    return output.get("result") == target.get("expected")


@evaluator()  # Will use function name
async def length_check(output, target):
    """Check if output length is reasonable"""
    result = output.get("result", "")
    return len(str(result)) > 0 